<?php
/**
 * Created by PhpStorm.
 * User: TyanBoot
 * Date: 2016/9/17
 * Time: 19:02
 */

namespace Config;


class Database
{
    public static $DB_TYPE = 'mysql';

    public static $DB_HOST = '192.168.1.11';

    public static $DB_USER = '9dc95e37-0212';

    public static $DB_PWD = 'f44f863a-8400';

    public static $DB = 'de8ba7ef2aeba44c3b77d1196c1916bd5';
}
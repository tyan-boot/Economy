<?php
/**
 * Created by PhpStorm.
 * User: TyanBoot
 * Date: 2016/9/17
 * Time: 14:17
 */

namespace Config;

class RouteCfg
{
    public static $DefaultRoute = 'Index';
}


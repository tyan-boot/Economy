<?php
/**
 * Created by PhpStorm.
 * User: TyanBoot
 * Date: 2016/9/17
 * Time: 14:19
 */

namespace Config;

class Config
{
    public static $SiteUrl = 'booteco.carp.mopaasapp.com';
    public static $UseHttps = false;
}

<?php
/**
 * Created by PhpStorm.
 * User: TyanBoot
 * Date: 2016/9/17
 * Time: 19:41
 */
?>

<script src="<?=$ViewUrl?>js/vendor/jquery.js"></script>
<script src="<?=$ViewUrl?>js/vendor/what-input.js"></script>
<script src="<?=$ViewUrl?>js/vendor/foundation.min.js"></script>
<script>
    $(document).foundation();
</script>

<p>Runtime is <?=$RunTime;?></p>
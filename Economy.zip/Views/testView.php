<!doctype html>

<html class="no-js" lang="zh_CN">

    <?php include 'header.php';?>

    <body>
        <div>
            <p>This is a test page</p>
        </div>

        <?php include 'footer.php';?>

    </body>
</html>
